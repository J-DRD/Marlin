Extract the firmware based on hardware drivers,
rename to firmware.bin and insert to rear-slot then power-on.